package com.example.flutter_project1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
