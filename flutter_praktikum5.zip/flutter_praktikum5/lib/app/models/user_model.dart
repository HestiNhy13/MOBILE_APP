import 'package:flutter/material.dart';

class UserModel{
  final String uid;
  final String email;

  UserModel({required this.uid, required this.email});
}