package com.example.flutter_praktikum5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
